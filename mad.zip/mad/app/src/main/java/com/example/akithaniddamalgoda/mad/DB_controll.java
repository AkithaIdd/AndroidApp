package com.example.akithaniddamalgoda.mad;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.TextView;

public class DB_controll extends SQLiteOpenHelper {
    public DB_controll(Context context,String pname, SQLiteDatabase.CursorFactory factory, int version) {
        super(context,"TEST.db", factory, version);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
       sqLiteDatabase.execSQL("CREATE TABLE USERS(ID INTEGER PRIMARY KEY AUTOINCREMENT,NAME TEXT UNIQUE,HEIGHT DOUBLE,WEIGHT DOUBLE,AGE DOUBLE);");

    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS USERS;");
        onCreate(sqLiteDatabase);

    }
    public void insert (String name,String height,String weight,String age){
        ContentValues contentValues = new ContentValues();
        contentValues.put("NAME",name);
        contentValues.put("HEIGHT",height);
        contentValues.put("WEIGHT",weight);
        contentValues.put("AGE",age);
        this.getWritableDatabase().insertOrThrow("USERS","",contentValues);

    }
    public void delete(String name){
        this.getWritableDatabase().delete("USERS","NAME='"+name+"'",null);
    }
    public void update(String old,String newname){
        this.getWritableDatabase().execSQL("UPDATE USERS SET NAME='"+newname+"'WHERE NAME='"+old+"'");
    }
    public void list_user(TextView list){
        Cursor cursor = this.getReadableDatabase().rawQuery("SELECT * FROM USERS",null);
        while (cursor.moveToNext()){
            list.append(cursor.getString(1)+" "+cursor.getString(2)+" "+cursor.getString(3)+" "+cursor.getString(4)+"\n");
        }
    }
}

