package com.example.akithaniddamalgoda.mad;

import android.app.Activity;
import android.content.DialogInterface;
import android.database.sqlite.SQLiteException;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.sql.SQLDataException;

public class MainActivity extends AppCompatActivity {
    EditText height,weight,age,name;
    TextView result,list;
    Button cal;
    DB_controll controll;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        height = (EditText) findViewById(R.id.height);
        weight = (EditText) findViewById(R.id.weight);
        age = (EditText) findViewById(R.id.age);
       result = (TextView) findViewById(R.id.result);
        cal = (Button) findViewById(R.id.cal);
        name = (EditText) findViewById(R.id.name);
        list = (TextView) findViewById(R.id.list);

        controll = new DB_controll(this,"",null,1);

        cal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                calcalorie();
            }
        });
        height.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {

                if (height.getText().length()<1){
                    height.setError("Enter the HEIGHT");
                }
            }

        });
        weight.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                String x=null;
                if (weight.getText().length()<1){
                    weight.setError("Enter the WEIGHT");
                }
            }

        });
        age.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                String x=null;
                if (age.getText().length()<1){
                    age.setError("Enter the AGE");
                }
            }

        });
    }
    private void calcalorie (){
        String hstr = height.getText().toString();
        String wstr = weight.getText().toString();
        String agestr = age.getText().toString();

        if (hstr != null && !"".equals(hstr)&& wstr != null && !"".equals(wstr) && agestr != null && !"".equals(agestr)){
            double h = Double.parseDouble(hstr);
            double w = Double.parseDouble(wstr);
            double a = Double.parseDouble(agestr);

           double cm = (13.75 * w) + (5.0 * h) - (6.76 * a) + 66.0;

            double cf = (9.56 * w) + (1.85 * h) - (4.68 * a) + 655.0;

           // displayCAL(cm);
           // displayCAL(cf);
            String res ="For men " + cm +" Calories" +"\n" +"For women "+ cf+" Calories";
           result.setText(res);
        }
    }

    public void btn_click(View view) {
        switch (view.getId()){
            case R.id.insert:


                try {
                    controll.insert(name.getText().toString(),height.getText().toString(),weight.getText().toString(),age.getText().toString());


                }catch (SQLiteException e){
                    Toast.makeText(MainActivity.this,"ALREADY EXISTS",Toast.LENGTH_SHORT).show();

                }

                break;
            case R.id.button2:
                controll.delete(name.getText().toString());
                break;
            case R.id.button3:
                AlertDialog.Builder dialog = new AlertDialog.Builder(MainActivity.this);
                dialog.setTitle("ENTER NEW NAME");

                final EditText newname = new EditText(this);
                dialog.setView(newname);
                dialog.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        controll.update(name.getText().toString(),newname.getText().toString());
                    }
                });
                dialog.show();
                break;
            case R.id.button4:
                controll.list_user(list);
                break;
        }
    }
}
