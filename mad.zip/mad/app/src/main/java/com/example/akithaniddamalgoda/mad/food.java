package com.example.akithaniddamalgoda.mad;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;


public class food extends AppCompatActivity {
    Button button;
    Button nbutton;

    Context c;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_food);
        c = this;
        nbutton = (Button)findViewById(R.id.button7);
        nbutton.setOnClickListener((view) -> {
            startActivity(new Intent(getApplicationContext(),MainActivity.class));

            Intent intent = new Intent(food.this,MainActivity.class);
            startActivity(intent);
        });



    }

    public void btn_click(View view) {
    }
}
    /*protected void onCreate(Bundle savedInstanceState) {
        c=this;
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_food);

        button= (Button)findViewById(R.id.button7);



    }

    /*   public Button button5;

    public void init(){
        button5 = (Button)findViewById(R.id.button5);
        button5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent toy = new Intent(food.this,foodcalary.class);
                startActivity(toy);
            }
        });
    }
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_food);
        init();
    }*/

   /*  Context c;

    @Override
    public void onCreate(Bundle savedInstanceState) {

        c = this;
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_food);

        ImageButton button = (ImageButton) findViewById(R.id.calary);
        ImageButton button2 = (ImageButton) findViewById(R.id.calc);
        ImageButton button1 = (ImageButton) findViewById(R.id.foodl);


        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(view.getContext(),foodcalary.class);
                startActivityForResult(intent,0);
               // Intent playListIntent = new Intent(c, foodcalary.class);
               // c.startActivity(playListIntent);
            }
        });

        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent playListIntent = new Intent(c, foodselect.class);
                c.startActivity(playListIntent);
            }


        });

        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(view.getContext(),foodcalary.class);
                startActivityForResult(intent,0);
            }

        });
    }*/




