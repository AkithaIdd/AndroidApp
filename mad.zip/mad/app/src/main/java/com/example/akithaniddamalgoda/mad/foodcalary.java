package com.example.akithaniddamalgoda.mad;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

public class foodcalary extends Activity {

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
    }
    public void showAlertDialog(View view){
        switch (view.getId()){
            case R.id.day1:
                AlertDialog alertDialog = new AlertDialog.Builder(this).create();
                alertDialog.setTitle("Day 1");
                alertDialog.setMessage("All fruits - Except bananas \n"+"Recommended fruits-Water Melon & Cantaloupe \n"+"8 to 12 glasses of water");
                alertDialog.setButton(DialogInterface.BUTTON_NEUTRAL, "OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Toast.makeText(getApplicationContext(),"Clicked OK",Toast.LENGTH_SHORT).show();
                    }
                });
                alertDialog.show();
                break;
            case R.id.day2:
                AlertDialog alertDialog1 = new AlertDialog.Builder(this).create();
                alertDialog1.setTitle("Day 2");
                alertDialog1.setMessage("Large boiled potato \n"+"Cooked or uncooked vegetables \n"+"8 to 12 glasses of water");
                alertDialog1.setButton(DialogInterface.BUTTON_NEUTRAL, "OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Toast.makeText(getApplicationContext(),"Clicked OK",Toast.LENGTH_SHORT).show();
                    }
                });
                alertDialog1.show();
                break;
            case R.id.Day3:
                AlertDialog alertDialog2 = new AlertDialog.Builder(this).create();
                alertDialog2.setTitle("Day 3");
                alertDialog2.setMessage("All fruits - Except bananas \n"+"Cooked or uncooked vegetables \n"+"8 to 12 glasses of water");
                alertDialog2.setButton(DialogInterface.BUTTON_NEUTRAL, "OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Toast.makeText(getApplicationContext(),"Clicked OK",Toast.LENGTH_SHORT).show();
                    }
                });
                alertDialog2.show();
                break;
            case R.id.Day4:
                AlertDialog alertDialog3 = new AlertDialog.Builder(this).create();
                alertDialog3.setTitle("Day 4");
                alertDialog3.setMessage("8 to 10 bananas \n" +"4 glasses of milk\n"+"8 to 12 glasses of water");
                alertDialog3.setButton(DialogInterface.BUTTON_NEUTRAL, "OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Toast.makeText(getApplicationContext(),"Clicked OK",Toast.LENGTH_SHORT).show();
                    }
                });
                alertDialog3.show();
                break;
            case R.id.Day5:
                AlertDialog alertDialog4 = new AlertDialog.Builder(this).create();
                alertDialog4.setTitle("Day 5");
                alertDialog4.setMessage("6 tomatoes\n"+"One cup of brown rice"+"12 to 15 glasses of water");
                alertDialog4.setButton(DialogInterface.BUTTON_NEUTRAL, "OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Toast.makeText(getApplicationContext(),"Clicked OK",Toast.LENGTH_SHORT).show();
                    }
                });
                alertDialog4.show();
                break;
            case R.id.Day6:
                AlertDialog alertDialog5 = new AlertDialog.Builder(this).create();
                alertDialog5.setTitle("Day 6");
                alertDialog5.setMessage("One cup of brown rice\n"+"Cooked or uncooked vegetables \n"+"8 to 12 glasses of water");
                alertDialog5.setButton(DialogInterface.BUTTON_NEUTRAL, "OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Toast.makeText(getApplicationContext(),"Clicked OK",Toast.LENGTH_SHORT).show();
                    }
                });
                alertDialog5.show();
                break;
            case R.id.Day7:
                AlertDialog alertDialog6 = new AlertDialog.Builder(this).create();
                alertDialog6.setTitle("Day 7");
                alertDialog6.setMessage("One cup of brown rice\n"+"Any vegetables\n"+"All friut juices");
                alertDialog6.setButton(DialogInterface.BUTTON_NEUTRAL, "OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Toast.makeText(getApplicationContext(),"Clicked OK",Toast.LENGTH_SHORT).show();
                    }
                });
                alertDialog6.show();
                break;
        }



    }
}

